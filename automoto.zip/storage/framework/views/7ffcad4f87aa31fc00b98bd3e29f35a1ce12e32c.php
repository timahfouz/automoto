<?php $__env->startSection('title'); ?>
    Categories
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="statbox widget box box-shadow" >
        <div class="widget-header" >
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4> Categories List

                    </h4>
                    <div class="float-lg-right">
                        <a class="btn btn-primary" href="<?php echo e(route('admin.categories.create')); ?>"> Add Category </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <div class="table-responsive">
                <table class="table table-bordered table-hover table-striped table-checkable table-highlight-head mb-4">

                    <thead>
                    <tr>
                        <th class="">Name</th>
                        <th class="">Default Category</th>
                        <th class="">Brands Category</th>
                        <th class="">Job Category</th>
                        <th class="text-center">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="checkbox-column">
                                <img class="avatar" src="<?php echo e(imagePath($item->image->path)); ?>" alt="">
                                <?php echo e($item->name); ?>

                            </td>
                            <td class="checkbox-column">
                                <span style="font-size: 18px;" class="fa fa-thumbs-<?php echo e((!$item->for_brands && !$item->for_jobs) ? 'up' : 'down'); ?> text-<?php echo e((!$item->for_brands && !$item->for_jobs) ? 'primary' : 'danger'); ?>"></span>
                            </td>
                            <td class="checkbox-column">
                                <span style="font-size: 18px;" class="fa fa-thumbs-<?php echo e($item->for_brands ? 'up' : 'down'); ?> text-<?php echo e($item->for_brands ? 'primary' : 'danger'); ?>"></span>
                            </td>
                            <td class="checkbox-column">
                                <span style="font-size: 18px;" class="fa fa-thumbs-<?php echo e($item->for_jobs ? 'up' : 'down'); ?> text-<?php echo e($item->for_jobs ? 'primary' : 'danger'); ?>"></span>
                            </td>

                            <td class="text-center">
                                <a data-toggle="tooltip" href="<?php echo e(route('admin.categories.edit', $item->id)); ?>"
                                data-placement="top" title="" data-original-title="Edit">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                        fill="none"
                                        stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                        stroke-linejoin="round"
                                        class="feather feather-edit-2 text-success">
                                        <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
                                    </svg>
                                </a>

                                <button style="border: 0;background: none" type="button"  data-placement="top" title=""
                                        data-original-title="Delet" data-toggle="modal" data-target="#deleteModal<?php echo e($item->id); ?>">

                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                        fill="none"
                                        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                        class="feather feather-trash-2 text-danger">
                                        <polyline points="3 6 5 6 21 6"></polyline>
                                        <path
                                            d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                        <line x1="10" y1="11" x2="10" y2="17"></line>
                                        <line x1="14" y1="11" x2="14" y2="17"></line>
                                    </svg>
                                </button>
                                <?php if (isset($component)) { $__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6 = $component; } ?>
<?php $component = App\View\Components\Admin\DeleteModal::resolve(['route' => $delte_route,'id' => $item->id] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.delete-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\DeleteModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6)): ?>
<?php $component = $__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6; ?>
<?php unset($__componentOriginalaabc33b3544465c83579d84ad4af895f5bda10b6); ?>
<?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>


            </div>


        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpWork\htdocs\automoto\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>