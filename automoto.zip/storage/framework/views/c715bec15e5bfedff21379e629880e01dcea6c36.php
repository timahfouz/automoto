<div class="row">
    <div class="form-group mb-4 col-md-4">
        <label for="name"> Choose Image: </label>
        <input type="file" class="form-control" id="image"
            name="image">
    </div>
    <div class="form-group mb-4 col-md-4">
        <label for="name"> Choose Background Image: </label>
        <input type="file" class="form-control" id="image"
            name="bg_image">
    </div>
</div>


<div class="row">
    <div class="form-group mb-4 col-md-8">
        <label for="name"> Vendor Name:</label>
        <input type="text" required class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name"
                name="name" placeholder="Name" value="<?php echo e(old('name', (isset($item) ? $item->name : ''))); ?>">
    </div>
</div>

<div class="row">
    <div class="form-group mb-4 col-md-8">
        <label for="geo_url"> Location from google map: <a style="color: blue;border-bottom: 1px dashed blue;" target="_blank" href="https://maps.google.com">Google maps</a></label>
        <input type="text" required class="form-control <?php $__errorArgs = ['geo_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="geo_url"
                name="geo_url" placeholder="Location from google map" value="<?php echo e(old('geo_url', (isset($item) ? $item->geo_url : ''))); ?>">
    </div>
</div>

<div class="row">
    <div class="form-group mb-4 col-md-4">
        <label for="name"> Vendor Phone:</label>
        <input type="text" required class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="phone"
                name="phone" placeholder="Phone" value="<?php echo e(old('phone', (isset($item) ? $item->phone : ''))); ?>">
    </div>
    <div class="form-group mb-4 col-md-4">
        <label for="name"> Vendor Whatsapp:</label>
        <input type="text" required class="form-control <?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="whatsapp"
                name="whatsapp" placeholder="Whatsapp" value="<?php echo e(old('whatsapp', (isset($item) ? $item->whatsapp : ''))); ?>">
    </div>
</div>

<div class="row">
    <div class="form-group mb-4 col-md-8">
        <label for="geo_url">Bio:</label>
        <textarea rows="10" required class="form-control <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="bio"
                name="bio" placeholder="Type something about this vendor" ><?php echo e(old('bio', (isset($item) ? $item->bio : ''))); ?></textarea>
    </div>
</div>


<div class="row">
    <div class="form-group mb-4 col-md-4">
        <label for="city_id"> Select City:</label>
        <select required class="form-control" id="city_id" name="city_id">
            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e((isset($item) ? ($item->city_id == $city->id) ? 'selected' : '' : '')); ?> value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group mb-4 col-md-4">
        <label for="category_id"> Select Category:</label>
        <select required class="form-control" id="category_id" name="category_id">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e((isset($item) ? ($item->category_id == $category->id) ? 'selected' : '' : '')); ?> value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    
</div>

<div class="row">

    <div class="form-group mb-4 col-md-4">
        <label for="brand_id"> Select Brand (optional):</label>
        <select class="form-control" id="brand_id" name="brand_id">
            <option value="">Select Brand</option>
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e((isset($item) ? ($item->brand_id == $brand->id) ? 'selected' : '' : '')); ?> value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group mb-4 col-md-4">
        <label for="brand_id"> Select Service (optional):</label>
        <select class="form-control" id="brand_id" name="brand_id">
            <option value="">Select Service</option>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e((isset($item) ? ($item->service_id == $service->id) ? 'selected' : '' : '')); ?> value="<?php echo e($service->id); ?>"><?php echo e($service->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

</div>

<label for="brand_id">Select type if it's a job service:</label>
<div class="row">
    <div class="form-group mb-4 col-md-2">
        <input type="radio" class="" id="is_new_job"
        name="service_type" value="is_new_job" <?php echo e((isset($item) && $item->is_new_job ? 'checked' : '')); ?>>
        <label for="is_new_job">New Job</label>
    </div>

    <div class="form-group mb-4 col-md-2">
        <input type="radio" class="" id="is_driver"
        name="service_type" value="is_driver" <?php echo e((isset($item) && $item->is_driver ? 'checked' : '')); ?>>
        <label for="is_driver">Is a driver</label>
    </div>
</div>


<!-- 
<div class="form-group mb-4 col-md-2">
    <label for="for_jobs">Job Service</label>
    <input type="checkbox" class="" id="for_jobs"
        name="for_jobs" <?php echo e((isset($item) && $item->for_jobs ? 'checked' : '')); ?>>
</div>


<div class="form-group mb-4 col-md-2">
    <label for="for_alarm">Alert Service</label>
    <input type="checkbox" class="" id="for_alarm"
        name="for_alarm" <?php echo e((isset($item) && $item->for_alarm ? 'checked' : '')); ?>>
</div> --><?php /**PATH D:\phpWork\htdocs\automoto\resources\views/admin/vendors/_form.blade.php ENDPATH**/ ?>