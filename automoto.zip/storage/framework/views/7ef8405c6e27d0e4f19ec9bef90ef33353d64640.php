<?php if(session()->has('success')): ?>
    <div class="alert alert-success" role="alert">
        تمت العملية بنجاح.
    </div>
<?php elseif(session()->has('error') || $errors->any()): ?>

    <div class="alert alert-danger" role="alert">
        <?php echo e($errors->first()); ?>

    </div>

<?php endif; ?><?php /**PATH D:\phpWork\htdocs\automoto\resources\views/components/feedback.blade.php ENDPATH**/ ?>