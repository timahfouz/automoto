<?php $__env->startSection('title'); ?>
    Edit User Data
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
                <div class="row">
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                        <h4>Edit User</h4>
                    </div>
                </div>
            </div>
            <?php if (isset($component)) { $__componentOriginala057529394eb7ae3e5c3fcfe178e41b8d7708036 = $component; } ?>
<?php $component = App\View\Components\Feedback::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feedback'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Feedback::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala057529394eb7ae3e5c3fcfe178e41b8d7708036)): ?>
<?php $component = $__componentOriginala057529394eb7ae3e5c3fcfe178e41b8d7708036; ?>
<?php unset($__componentOriginala057529394eb7ae3e5c3fcfe178e41b8d7708036); ?>
<?php endif; ?>
            <div class="widget-content widget-content-area">
                <?php echo e(Form::open(['route' => ['admin.users.update', $item->id], 'method' => 'PUT', 'files' => true ])); ?>


                    <?php echo $__env->make('admin.users._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <input type="submit" value="Save" class="mt-4 mb-4 btn btn-primary">
                <?php echo e(Form::close()); ?>


            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpWork\htdocs\automoto\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>