<div class="row">
    <div class="form-group mb-4 col-md-4">
        <label for="name"> Choose Image: </label>
        <input type="file" class="form-control" id="image"
            name="image">
    </div>
</div>


<div class="row">
    <div class="form-group mb-4 col-md-6">
        <label for="name"> Service Name:</label>
        <input type="text" required class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name"
                name="name" placeholder="Name" value="<?php echo e(old('name', (isset($item) ? $item->name : ''))); ?>">
    </div>
</div>


<div class="row">
    <div class="form-group mb-4 col-md-6">
        <label for="city_id"> Select City:</label>
        <select required class="form-control" id="city_id" name="city_id">
            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e((isset($item) ? ($item->city_id == $city->id) ? 'selected' : '' : '')); ?> value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>

<div class="row">
    <div class="form-group mb-4 col-md-6">
        <label for="category_id"> Select Category:</label>
        <select required class="form-control" id="category_id" name="category_id">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e((isset($item) ? ($item->category_id == $category->id) ? 'selected' : '' : '')); ?> value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>
<!-- 
<div class="row">
    <div class="form-group mb-4 col-md-6">
        <label for="brand_id"> Select Brand (optional):</label>
        <select required class="form-control" id="brand_id" name="brand_id">
            <option value="">Select Brand</option>
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e((isset($item) ? ($item->brand_id == $brand->id) ? 'selected' : '' : '')); ?> value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>

<div class="form-group mb-4 col-md-2">
    <label for="for_jobs">Job Service</label>
    <input type="checkbox" class="" id="for_jobs"
        name="for_jobs" <?php echo e((isset($item) && $item->for_jobs ? 'checked' : '')); ?>>
</div>


<div class="form-group mb-4 col-md-2">
    <label for="for_alarm">Alert Service</label>
    <input type="checkbox" class="" id="for_alarm"
        name="for_alarm" <?php echo e((isset($item) && $item->for_alarm ? 'checked' : '')); ?>>
</div> --><?php /**PATH D:\phpWork\htdocs\automoto\resources\views/admin/services/_form.blade.php ENDPATH**/ ?>