<?php $__env->startSection('title'); ?>
    Creating Area
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
                <div class="row">
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                        <h4>Admin Details</h4>
                    </div>
                </div>
            </div>
            <div class="widget-content widget-content-area">
            <?php echo e(Form::open(['route' => ['admin.areas.store'], 'method' => 'POST' ])); ?>


                <?php echo $__env->make('admin.areas._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <input type="submit" value="Save" class="mt-4 mb-4 btn btn-primary">
            <?php echo e(Form::close()); ?>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpWork\htdocs\automoto\resources\views/admin/areas/create.blade.php ENDPATH**/ ?>