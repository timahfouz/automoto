
<div class="row">
    <div class="form-group mb-4 col-md-6">
        <label for="parent_id"> Select City:</label>
        <select required class="form-control" id="parent_id" name="parent_id">
            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e((isset($item) ? ($item->parent_id == $city->id) ? 'selected' : '' : '')); ?> value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>

<div class="row">
    <div class="form-group mb-4 col-md-6">
        <label for="name"> Area Name:</label>
        <input type="text" required class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name"
                name="name" placeholder="Name" value="<?php echo e(old('name', (isset($item) ? $item->name : ''))); ?>">
    </div>
</div>
<?php /**PATH D:\phpWork\htdocs\automoto\resources\views/admin/areas/_form.blade.php ENDPATH**/ ?>