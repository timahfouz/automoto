<?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div id="content" class="main-content">
    <?php echo $__env->yieldContent('content'); ?>
</div>

<?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->yieldPushContent('scripts'); ?><?php /**PATH D:\phpWork\htdocs\automoto\resources\views/admin/layout/master.blade.php ENDPATH**/ ?>