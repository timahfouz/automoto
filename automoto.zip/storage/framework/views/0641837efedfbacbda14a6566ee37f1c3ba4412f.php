
<div class="modal fade" id="deleteModal<?php echo e($id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <?php echo e(Form::open(['route' => [$route, $id], 'method' => 'DELETE' ])); ?>

    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Delete</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Do you really want to delete this item?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-danger">Delete</button>
      </div>
    </div>
    <?php echo e(Form::close()); ?>

  </div>
</div><?php /**PATH D:\phpWork\htdocs\automoto\resources\views/components/admin/delete-modal.blade.php ENDPATH**/ ?>