<div class="row">
    <div class="form-group mb-4 col-md-4">
        <label for="name"> Choose Image: </label>
        <input type="file" class="form-control" id="image"
            name="image">
    </div>
</div>

<div class="row">
    <div class="form-group mb-4 col-md-4">
        <label for="name"> Name:</label>
        <input type="text" required class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name"
                name="name" placeholder="Name" value="<?php echo e(old('name', (isset($item) ? $item->name : ''))); ?>">
    </div>

    <div class="form-group mb-4 col-md-4">
        <label for="phone"> Phone:</label>
        <input type="text" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="phone"
                name="phone" placeholder="Phone" value="<?php echo e(old('phone', (isset($item) ? $item->phone : '') )); ?>">
    </div>

    <div class="form-group mb-4 col-md-4">
        <label for="email"> Email:</label>
        <input type="email" required class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email"
                name="email" placeholder="Email" value="<?php echo e(old('email', (isset($item) ? $item->email : '') )); ?>">
    </div>
</div>


<div class="row">
    <div class="form-group mb-4 col-md-6">
        <label for="password">Password:</label>
        <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password"
            name="password" placeholder="Password">
    </div>
    <div class="form-group mb-4 col-md-6">
        <label for="password_confirmation"> Confirm Password:</label>
        <input type="password" class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password_confirmation"
            name="password_confirmation" placeholder="Confirm Password">
    </div>
</div>


<div class="form-group mb-4 col-md-6">
    <label for="verified"> Activate / Deactivate:</label>
    <input type="checkbox" class="" id="verified"
        name="verified" <?php echo e((isset($item) && $item->verified ? 'checked' : '')); ?>>
</div><?php /**PATH D:\phpWork\htdocs\automoto\resources\views/admin/users/_form.blade.php ENDPATH**/ ?>